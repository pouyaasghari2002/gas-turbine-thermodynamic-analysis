clear;clc;
%% Adding Coolprop
addpath('cool');

%% Calling CoolProp

h1 = CoolProp.PropsSI('H' ,'T',298,'P',100000,'R134a')

s1 = CoolProp.PropsSI('S' ,'P',1e6,'Q',0.8,'Water')


%% Improving Notation

T(1) = 298;
P(1) = 100000;
h(1) = CoolProp.PropsSI('H' ,'T',T(1),'P',P(1),'Air');
s(1) = CoolProp.PropsSI('S' ,'T',T(1),'P',P(1),'Air');



